package acquisition_mieux.ecouteurs.awt;

import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import acquisition_mieux.ecouteurs.EcouteurSaisieCourbe;

public class EcouteurSaisieCourbeAWT extends EcouteurSaisieCourbe implements MouseMotionListener
{

@Override
public void mouseDragged(MouseEvent e)
{
this.dernierePosition(e.getX(), e.getY());
}

@Override
public void mouseMoved(MouseEvent e)
{
// TODO Auto-generated method stub

}

}
