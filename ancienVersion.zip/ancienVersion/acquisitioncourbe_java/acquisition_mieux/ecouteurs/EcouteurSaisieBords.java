package acquisition_mieux.ecouteurs;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import acquisition_mieux.VueSaisieCourbeGUI;



public class EcouteurSaisieBords extends Ecouteur implements ActionListener
{
public EcouteurSaisieBords(VueSaisieCourbeGUI vueSaisieCourbeGUI)
    {
    super(vueSaisieCourbeGUI);
    }

@Override
public void actionPerformed(ActionEvent arg0)
{
this.vueSaisieCourbeGUI.initialiseTranformationsAffines1();
}

}
