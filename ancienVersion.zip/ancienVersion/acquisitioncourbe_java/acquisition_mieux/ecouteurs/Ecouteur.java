package acquisition_mieux.ecouteurs;

import java.awt.event.ActionListener;

import acquisition_mieux.VueSaisieCourbeGUI;

public class Ecouteur
{

protected VueSaisieCourbeGUI vueSaisieCourbeGUI;

/**
 * @param vueSaisieCourbeGUI
 */
public Ecouteur(VueSaisieCourbeGUI vueSaisieCourbeGUI)
{
this.vueSaisieCourbeGUI = vueSaisieCourbeGUI;
}



}