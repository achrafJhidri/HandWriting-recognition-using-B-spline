package acquisition_mieux.ecouteurs;

public interface EcouteurPositionPointeur
{
void dernierePosition( int xPointeur, int yPointeur);
}
