package acquisition_mieux;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import acquisition_mieux.ecouteurs.Ecouteur;

public class EcouteurSauver extends Ecouteur implements ActionListener
{

public EcouteurSauver(VueSaisieCourbeGUI vueSaisieCourbeGUI)
{
super(vueSaisieCourbeGUI);
}

//@Override
public void actionPerformed1(ActionEvent e)
{
try
{
JFileChooser fileSaver = new JFileChooser(new File("").getAbsoluteFile());
int r = fileSaver.showSaveDialog(this.vueSaisieCourbeGUI.cadre);

if (r == JFileChooser.APPROVE_OPTION)
    {
    File file = fileSaver.getSelectedFile();
    System.err.println("r = "+ r + " "+ file.getAbsolutePath());
    PrintStream ps = new PrintStream(file);
    this.vueSaisieCourbeGUI.courbe.sauve(ps);
    }
}
catch (FileNotFoundException e1)
    {
    JOptionPane.showMessageDialog(this.vueSaisieCourbeGUI.cadre, 
                                    "sauvegarde impossible", 
                                    "erreur de sauvegarde", 
                                    JOptionPane.ERROR_MESSAGE);
    }
}

/* (non-Javadoc)
 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
 */
@Override
public void actionPerformed(ActionEvent arg0)
{
this.vueSaisieCourbeGUI.sauveCourbe();
}


}
