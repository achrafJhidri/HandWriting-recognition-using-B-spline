package acquisition_mieux;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics;

import outilsvues.MonGraphics;

import mesmaths.geometrie.base.Vecteur;
import mesmaths.geometrie.base.TransformationAffine;



public class MonCanvas extends Canvas
{
VueSaisieCourbeGUI vue;
    /* (non-Javadoc)
     * @see java.awt.Canvas#paint(java.awt.Graphics)
     */
    public MonCanvas(VueSaisieCourbeGUI vue)
{
this.vue = vue;
this.setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
this.setBackground(Color.LIGHT_GRAY);
}
    
@Override
public void paint(Graphics arg0)
{
int x0, y0, l, h;
Vecteur vBG,vHD;

vBG = this.vue.t_1.applique(this.vue.vMin);
vHD = this.vue.t_1.applique(this.vue.vMax);
x0 = (int)vBG.x;
y0 = (int)vHD.y;
l = (int)vHD.x - x0;
h = (int)vBG.y - y0;
arg0.setColor(Color.white);

arg0.fillRect(x0, y0, l, h);

if (vue.courbe != null) 
    {
    MonGraphics monGraphics = new MonGraphics(arg0);
    
    monGraphics.traceCourbe(this.vue.t_1, this.vue.courbe.getPoints(), Color.BLACK);
    }
}
    
}
