package acquisition_mieux;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import acquisition_mieux.ecouteurs.Ecouteur;

public class EcouteurEffacer extends Ecouteur implements ActionListener
{

public EcouteurEffacer(VueSaisieCourbeGUI vueSaisieCourbeGUI)
{
super(vueSaisieCourbeGUI);
}

@Override
public void actionPerformed(ActionEvent e)
{
this.vueSaisieCourbeGUI.quitteEtat3();
this.vueSaisieCourbeGUI.entreEtat0();
}

}
