package acquisition_mieux;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class EcouteurCanvas extends Ecouteur implements MouseListener
{

public EcouteurCanvas(VueSaisieCourbeGUI vueSaisieCourbeGUI)
{
super(vueSaisieCourbeGUI);
}

@Override
public void mouseClicked(MouseEvent e)
{
// TODO Auto-generated method stub

}

@Override
public void mouseEntered(MouseEvent e)
{
this.vueSaisieCourbeGUI.quitteEtat0();
this.vueSaisieCourbeGUI.entreEtat1();
}

@Override
public void mouseExited(MouseEvent e)
{
this.vueSaisieCourbeGUI.quitteEtat1();
this.vueSaisieCourbeGUI.entreEtat0();
}

@Override
public void mousePressed(MouseEvent e)
{
// TODO Auto-generated method stub

}

@Override
public void mouseReleased(MouseEvent e)
{
// TODO Auto-generated method stub

}

}
