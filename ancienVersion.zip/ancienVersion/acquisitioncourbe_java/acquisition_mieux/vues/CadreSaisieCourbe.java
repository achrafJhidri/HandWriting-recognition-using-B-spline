package acquisition_mieux.vues;

import java.awt.Button;
import java.awt.Label;
import java.awt.TextField;
import java.util.Observable;

import acquisition_mieux.MonCanvas;
import acquisition_mieux.VueSaisieCourbeGUI;

public interface CadreSaisieCourbe
{
Label pr�sentation;
Label labelsaisieL�gende; TextField saisieL�gende;

Label labelX, labelY; TextField sortieT, sortieX, sortieY;
Label labelSaisiePointBasGauche, labelSaisiePointHautDroit;
TextField saisiePointBasGauche, saisiePointHautDroit;

MonCanvas canvas;
TextField message;

void setVueSaisieCourbe(VueSaisieCourbeGUI vueSaisieCourbe);

public String getLegende(); // saisie L�gende
public String getPointBasGauche(); // saisie point bas gauche
public String getPointHautDroit(); // saisie point haut droit
public void setSortieT();
public void setSortieX();
public void setSortieY();
public void setMessage();
public Observable getBoutonToutEffacer();//Button  toutEffacer;

public Observable getBoutonSauver();//Button  sauver;


}