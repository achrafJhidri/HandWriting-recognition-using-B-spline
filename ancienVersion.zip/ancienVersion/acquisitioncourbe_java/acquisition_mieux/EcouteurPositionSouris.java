package acquisition_mieux;

import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import acquisition_mieux.ecouteurs.Ecouteur;
import mesmaths.geometrie.base.Vecteur;
import mesmaths.geometrie.base.TransformationAffine;



public class EcouteurPositionSouris extends Ecouteur implements
        MouseMotionListener
{

public EcouteurPositionSouris(VueSaisieCourbeGUI vueSaisieCourbeGUI)
    {
    super(vueSaisieCourbeGUI);
    }

@Override
public void mouseDragged(MouseEvent arg0)
{
travaille(arg0);
}

@Override
public void mouseMoved(MouseEvent arg0)
{
travaille(arg0);
}

private void travaille(MouseEvent arg0)
{
Vecteur v = new Vecteur(arg0.getX(), arg0.getY());
Vecteur v1 = this.vueSaisieCourbeGUI.t.applique(v); //ces 2 lignes sont r�p�t�es dans EcouteurSaisieCourbe
this.vueSaisieCourbeGUI.cadre.sortieX.setText(Double.toString(v1.x));
this.vueSaisieCourbeGUI.cadre.sortieY.setText(Double.toString(v1.y));
}



}
