package acquisition;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class EcouteurEffacer extends Ecouteur implements ActionListener
{

public EcouteurEffacer(VueSaisieCourbeGUI vueSaisieCourbeGUI)
{
super(vueSaisieCourbeGUI);
}

@Override
public void actionPerformed(ActionEvent e)
{
this.vueSaisieCourbeGUI.quitteEtat3();
this.vueSaisieCourbeGUI.entreEtat0();
}

}
