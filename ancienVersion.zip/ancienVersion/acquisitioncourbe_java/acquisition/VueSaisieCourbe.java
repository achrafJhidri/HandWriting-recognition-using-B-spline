package acquisition;

import acquisition.modele.CourbeLegendee;

public interface VueSaisieCourbe
{
public void montreService(String serviceOffert);
/**
 * @return une courbe l�gend�e ou null en cas d'abandon de l'utilisateur
 * 
 * */
public CourbeLegendee renseigne();

public void cache();
}
