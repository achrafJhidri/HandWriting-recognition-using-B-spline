package acquisition;

public class TestCadreSaisieCourbe
{

/**
 * @param args
 */
public static void main(String[] args)
{
CadreSaisieCourbe cadreSaisieCourbe = new CadreSaisieCourbe("acquisition d'une courbe trac�e par la main",
        "saisie de courbe trac�e � la main."+
        " Les triplets ( t, x(t), y(t) )  instant-position successifs sont saisis ",
        "saisie de la l�gende de la courbe",
        "saisie point bas gauche","(0,0)","saisie point haut droit","(1,1)",
        "tout effacer","sauver",
        "d�but de courbe <--> enfoncer bouton gauche souris. fin de courbe <--> rel�cher bouton gauche souris",null);
cadreSaisieCourbe.setVisible(true);

}

}
