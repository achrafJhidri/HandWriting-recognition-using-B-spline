package acquisition;

import java.awt.event.ActionListener;

public class Ecouteur
{

protected VueSaisieCourbeGUI vueSaisieCourbeGUI;

/**
 * @param vueSaisieCourbeGUI
 */
public Ecouteur(VueSaisieCourbeGUI vueSaisieCourbeGUI)
{
this.vueSaisieCourbeGUI = vueSaisieCourbeGUI;
}



}