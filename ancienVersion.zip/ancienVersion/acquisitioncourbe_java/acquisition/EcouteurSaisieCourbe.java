package acquisition;

import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import mesmaths.geometrie.base.InstantPosition;
import mesmaths.geometrie.base.Vecteur;
import mesmaths.geometrie.base.TransformationAffine;

import acquisition.modele.Vecteur3D;


public class EcouteurSaisieCourbe extends Ecouteur implements
        MouseMotionListener
{

public EcouteurSaisieCourbe(VueSaisieCourbeGUI vueSaisieCourbeGUI)
{
super(vueSaisieCourbeGUI);
// TODO Auto-generated constructor stub
}

@Override
public void mouseDragged(MouseEvent e)
{
Vecteur v1 = new Vecteur(e.getX(),e.getY());

Vecteur v2 = this.vueSaisieCourbeGUI.t.applique(v1); //ces 2 lignes sont r�p�t�es dans EcouteurPositionSouris

double t = System.currentTimeMillis() - this.vueSaisieCourbeGUI.�couteurD�butSaisieCourbe.debut;

//this.vueSaisieCourbeGUI.courbe.add(new Vecteur3D( t, v2.x, v2.y));
this.vueSaisieCourbeGUI.courbe.add(new InstantPosition(t, v2));

this.vueSaisieCourbeGUI.cadre.sortieT.setText(Double.toString(t));
this.vueSaisieCourbeGUI.cadre.canvas.repaint();

}

@Override
public void mouseMoved(MouseEvent e)
{
// TODO Auto-generated method stub

}

}
