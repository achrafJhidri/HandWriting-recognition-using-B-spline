package acquisition;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class EcouteurFinSaisieCourbe extends Ecouteur implements MouseListener
{

public EcouteurFinSaisieCourbe(VueSaisieCourbeGUI vueSaisieCourbeGUI)
{
super(vueSaisieCourbeGUI);
// TODO Auto-generated constructor stub
}

@Override
public void mouseClicked(MouseEvent e)
{
// TODO Auto-generated method stub

}

@Override
public void mouseEntered(MouseEvent e)
{
// TODO Auto-generated method stub

}

@Override
public void mouseExited(MouseEvent e)
{
this.vueSaisieCourbeGUI.quitteEtat2();
this.vueSaisieCourbeGUI.entreEtat0();
}

@Override
public void mousePressed(MouseEvent e)
{
// TODO Auto-generated method stub

}

@Override
public void mouseReleased(MouseEvent e)
{
if (e.getButton() == MouseEvent.BUTTON1)
    {
    this.vueSaisieCourbeGUI.quitteEtat2();
    this.vueSaisieCourbeGUI.entreEtat3();
    }
}


}
