package acquisition;

import java.awt.Graphics;

public interface Sc�ne
{

    void dessiner(Graphics arg0);

}
