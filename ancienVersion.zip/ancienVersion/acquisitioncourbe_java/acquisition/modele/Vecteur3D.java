package acquisition.modele;

public class Vecteur3D
{
double t,x,y;

/**
 * @param t
 * @param x
 * @param y
 */
public Vecteur3D(double t, double x, double y)
{
this.t = t;
this.x = x;
this.y = y;
}

/* (non-Javadoc)
 * @see java.lang.Object#toString()
 */
@Override
public String toString()
{
return "(" + this.t + ", " + this.x + ", " + this.y + ")";
}


}
