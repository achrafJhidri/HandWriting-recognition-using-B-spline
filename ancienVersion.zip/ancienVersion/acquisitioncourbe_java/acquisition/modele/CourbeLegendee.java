package acquisition.modele;

import java.io.PrintStream;
import java.io.Serializable;
import java.util.Vector;

import mesmaths.geometrie.base.InstantPosition;
import mesmaths.geometrie.base.Vecteur;



/**
 * repr�sente une ligne bris�e de points de la forme (t,x(t),y(t)) munie d'une l�gende
 * 
 * 
 * */
public class CourbeLegendee implements Serializable
{
String l�gende;
Vector<InstantPosition> points;
/**
 * @param l�gende
 */
public CourbeLegendee(String l�gende)
{
this.l�gende = l�gende;
this.points = new Vector<InstantPosition>();
}

public String getL�gende()
{
return this.l�gende;
}

public void setL�gende(String l�gende)
{
this.l�gende = l�gende;
}

/**
 * @param arg0
 * @return
 * @see java.util.Vector#add(java.lang.Object)
 */
public boolean add(InstantPosition arg0)
{
return this.points.add(arg0);
}

/**
 * @param arg0
 * @return
 * @see java.util.Vector#get(int)
 */
public InstantPosition get(int arg0)
{
return this.points.get(arg0);
}

/**
 * @return
 * @see java.util.Vector#size()
 */
public int size()
{
return this.points.size();
}

@Override
public String toString()
{
int i;
String s;

s = this.l�gende+"\n"+this.size()+"\n";

for (i = 0; i < this.size(); ++i)
    s+= this.get(i)+"\n";

return s;      
}

public void sauve(PrintStream f)
{
int i;
String s;
f.println(this.l�gende);
f.println(this.size());
for (i = 0; i < this.size(); ++i)
    f.println(this.get(i));
f.close();     
}

public Vector<Vecteur> getPoints()
{
Vector<Vecteur> r = new Vector<Vecteur>();

int i;
for ( i = 0; i < this.size(); ++i)
    r.add(this.get(i).position);
return r;
}

}
