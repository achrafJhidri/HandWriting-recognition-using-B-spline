package acquisition.modele;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import mesmaths.geometrie.base.InstantPosition;
import mesmaths.geometrie.base.Vecteur;

public class TestCourbeLegendee
{

public static void main(String[] args)
{
try
    {
    CourbeLegendee courbe1 = new CourbeLegendee("ma petite courbe");
    
    courbe1.add(new InstantPosition(0.3, new Vecteur(2, 3)));
    courbe1.add(new InstantPosition(0.7, new Vecteur(4, -2)));
    courbe1.add(new InstantPosition(0.25, new Vecteur(-11, 7)));
    
    System.out.println("courbe1 = " + courbe1);
    
    int c;
    c = System.in.read();
    
    File racine = new File(""); // racine
    File donnees = new File(racine.getAbsoluteFile(),"acquisition"+File.separatorChar+"modele"+File.separatorChar+"donnees");
    String nomFichier = donnees.getAbsolutePath()+File.separatorChar+"courbe1.seri";
    FileOutputStream f1 = new FileOutputStream(nomFichier);
    
    ObjectOutputStream f2 = new ObjectOutputStream(f1);
    
    f2.writeObject(courbe1);
    
    courbe1 = null;
    
    FileInputStream g1 = new FileInputStream(nomFichier);
    ObjectInputStream g2 = new ObjectInputStream(g1);
    
    CourbeLegendee courbe2 = (CourbeLegendee)g2.readObject();
    
    System.out.println("courbe2 = " + courbe2);
    }
catch (IOException e)
    {
    // TODO Auto-generated catch block
    e.printStackTrace();
    }
catch (ClassNotFoundException e)
    {
    // TODO Auto-generated catch block
    e.printStackTrace();
    }


}

}
