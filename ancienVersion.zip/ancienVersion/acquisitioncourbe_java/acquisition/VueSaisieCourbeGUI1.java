package acquisition;

public class VueSaisieCourbeGUI1 extends VueSaisieCourbeGUI
{

public VueSaisieCourbeGUI1(double xMin, double yMin, double xMax, double yMax,
        CadreSaisieCourbe cadre)
{
super(xMin, yMin, xMax, yMax, cadre);
// TODO Auto-generated constructor stub
}

/* (non-Javadoc)
 * @see acquisition.VueSaisieCourbeGUI#entreEtat0()
 */
@Override
void entreEtat0()
{
System.err.println("entre �tat 0");
super.entreEtat0();
}

/* (non-Javadoc)
 * @see acquisition.VueSaisieCourbeGUI#entreEtat1()
 */
@Override
void entreEtat1()
{
System.err.println("entre �tat 1");
super.entreEtat1();
}

/* (non-Javadoc)
 * @see acquisition.VueSaisieCourbeGUI#entreEtat2()
 */
@Override
void entreEtat2()
{
System.err.println("entre �tat 2");
super.entreEtat2();
}

/* (non-Javadoc)
 * @see acquisition.VueSaisieCourbeGUI#entreEtat3()
 */
@Override
void entreEtat3()
{
System.err.println("entre �tat 3");
super.entreEtat3();
}

/* (non-Javadoc)
 * @see acquisition.VueSaisieCourbeGUI#quitteEtat0()
 */
@Override
void quitteEtat0()
{
System.err.println("quitte �tat 0");
super.quitteEtat0();
}

/* (non-Javadoc)
 * @see acquisition.VueSaisieCourbeGUI#quitteEtat1()
 */
@Override
void quitteEtat1()
{
System.err.println("quitte �tat 1");
super.quitteEtat1();
}

/* (non-Javadoc)
 * @see acquisition.VueSaisieCourbeGUI#quitteEtat2()
 */
@Override
void quitteEtat2()
{
System.err.println("quitte �tat 2");
super.quitteEtat2();
}

/* (non-Javadoc)
 * @see acquisition.VueSaisieCourbeGUI#quitteEtat3()
 */
@Override
void quitteEtat3()
{
System.err.println("quitte �tat 3");
super.quitteEtat3();
}



}
