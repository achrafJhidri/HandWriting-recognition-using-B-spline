package com.example.acquisitioncourbe;

import android.util.Log;
import android.view.MotionEvent;
import android.view.View;


/**
 * Contrôleur de l'état 0 : aucun doigt ne touche la surface de dessin
 *
 * */
public class ControleurEtat0 extends ControleurEtat
{
public  int iD1;           // identifiant du  1er doigt posé

public ControleurEtat0(Diagramme diagramme, ControleurEtat précédent, ControleurEtat suivant)
{
super(diagramme, précédent, suivant);
}

   @Override
public boolean onTouch(View v, MotionEvent event)
{
int action = event.getActionMasked();
int pointerCount = event.getPointerCount();
int actionIndex = event.getActionIndex();

Log.e(ActiviteAcquisition.TAG, "début ControleurEtat0.onTouch(), action = " + action + ", pointerCount = " + pointerCount + ", actionIndex = " + actionIndex);

/*
 * réagit uniquement lorsque le 1er doigt se pose, on note l'identifiant et la position de ce doigt. L'identifiant restera constant
 * tant que l'utilisateur n'aura pas levé ce doigt
 * */
if (event.getActionMasked() == MotionEvent.ACTION_DOWN)
   {
   this.iD1 = event.getPointerId(0);

   this.suivant.init();
   this.diagramme.controleurEtatCourant = this.suivant;
   }

return true;
}

@Override
public void init()
{
super.init();
this.diagramme.createurCourbeDessineeAndroid.set();
//this.setChanged();
//this.notifyObservers();

}
}
