package com.example.acquisitioncourbe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.pm.ActivityInfo;
import android.os.Bundle;

public class ActiviteAcquisition extends AppCompatActivity
{
public static final String TAG = "ActiviteAcquisition";
CreateurCourbeDessineeAndroid createurCourbeDessineeAndroid;

@Override
protected void onCreate(Bundle savedInstanceState)
{
//this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
super.onCreate(savedInstanceState);
setContentView(R.layout.layout_acquisition);
this.createurCourbeDessineeAndroid = new CreateurCourbeDessineeAndroid(this);
}
}
