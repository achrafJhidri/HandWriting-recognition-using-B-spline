package com.example.acquisitioncourbe;

import android.graphics.Canvas;
import android.graphics.Paint;

import androidx.annotation.NonNull;

import mesmaths.geometrie.base.Vecteur;

public class MonCanvas extends Canvas
{
Canvas canvas;

public MonCanvas(Canvas canvas)
{
this.canvas = canvas;
}

public void drawLine(Vecteur debut, Vecteur fin, @NonNull Paint paint)
{
this.canvas.drawLine((float) debut.x, (float) debut.y, (float) fin.x, (float) fin.y, paint);
}
}
