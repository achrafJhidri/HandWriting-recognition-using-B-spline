package com.example.acquisitioncourbe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ActiviteSauvegarde extends AppCompatActivity
{
EditText saisieNomFichier;
Button boutonValiderSauvegarde;
Button boutonRetourAcquisition;
TextView messageSauvegarde;
EcouteurSauvegarde ecouteurSauvegarde;
EcouteurRetourAcquisition ecouteurRetourAcquisition;

@Override
protected void onCreate(Bundle savedInstanceState)
{
super.onCreate(savedInstanceState);
setContentView(R.layout.layout_sauvegarde);

this.saisieNomFichier = (EditText)this.findViewById(R.id.saisieNomFichier);
this.boutonValiderSauvegarde = (Button)this.findViewById(R.id.boutonValiderSauvegarde);
this.messageSauvegarde = (TextView)this.findViewById(R.id.messageSauvegarde);
this.boutonRetourAcquisition = (Button)this.findViewById(R.id.boutonRetourAcquisition);
this.ecouteurSauvegarde = new EcouteurSauvegarde(this);
this.boutonValiderSauvegarde.setOnClickListener(this.ecouteurSauvegarde);
this.ecouteurRetourAcquisition = new EcouteurRetourAcquisition(this);
this.boutonRetourAcquisition.setOnClickListener(this.ecouteurRetourAcquisition);
}
}
