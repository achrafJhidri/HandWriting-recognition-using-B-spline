package com.example.acquisitioncourbe;

import android.content.Intent;
import android.util.Log;
import android.view.View;

/**
 * Chargé de sauvegarder la courbe
 * uniquement actif pendant l'état 3.
 * */
public class EcouteurSauver implements View.OnClickListener
{
CreateurCourbeDessineeAndroid createurCourbeDessineeAndroid;

public EcouteurSauver(CreateurCourbeDessineeAndroid createurCourbeDessineeAndroid)
{
this.createurCourbeDessineeAndroid = createurCourbeDessineeAndroid;
}

@Override
public void onClick(View v)
{
this.createurCourbeDessineeAndroid.message.setText("sauvegarde courbe");

//Intent intent = new Intent(this.createurCourbeDessineeAndroid.activiteAcquisition.getString(R.string.sauvegardeExterne));
//intent.addCategory(this.createurCourbeDessineeAndroid.activiteAcquisition.getString(R.string.sauvegarde));

Intent intent = new Intent("sauvegarde_externe");
intent.addCategory("sauvegarde");

intent.putExtra("courbe",this.createurCourbeDessineeAndroid.courbe);
//intent.putExtra( this.createurCourbeDessineeAndroid.activiteAcquisition.getString(R.string.titreCourbe),
//                 this.createurCourbeDessineeAndroid.saisieLegende.getText());
//intent.putExtra( this.createurCourbeDessineeAndroid.activiteAcquisition.getString(R.string.nombreLignes),
//                 this.createurCourbeDessineeAndroid.courbe.size());
//
//intent.putExtra( this.createurCourbeDessineeAndroid.activiteAcquisition.getString(R.string.pointsASauver),
//                 this.createurCourbeDessineeAndroid.courbe.toString("\n"));
Log.e(ActiviteAcquisition.TAG,"intent = " + intent);
this.createurCourbeDessineeAndroid.activiteAcquisition.startActivity(intent);
}
}
