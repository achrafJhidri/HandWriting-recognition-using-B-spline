package com.example.acquisitioncourbe;

import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import mesmaths.geometrie.base.InstantPosition;
import mesmaths.geometrie.base.Vecteur;

/**
 * Contrôleur de l'état 1 : un doigt  touche la surface de dessin
 *
 * */
public class ControleurEtat1 extends ControleurEtat
{
long instantInitial;

public ControleurEtat1(Diagramme diagramme, ControleurEtat précédent, ControleurEtat suivant)
{
super(diagramme, précédent, suivant);
}

@Override
public boolean onTouch(View v, MotionEvent event)
{
int action = event.getActionMasked();
int pointerCount = event.getPointerCount();
int actionIndex = event.getActionIndex();
Log.e(ActiviteAcquisition.TAG, "début ControleurEtat1.onTouch(), action = " + action + ", pointerCount = " + pointerCount + ", actionIndex = " + actionIndex);

this.instantInitial = System.currentTimeMillis();
// récupère l'index du 1er doigt qui avait été posé
int index = event.findPointerIndex(((ControleurEtat0)(this.diagramme.controleurEtat0)).iD1);

if ((action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP) && actionIndex == index)
   {
   this.précédent.init(); this.diagramme.controleurEtatCourant = this.précédent; return true;
   } // le 1er pointeur s'est détaché

int x = (int)event.getX(index);
int y = (int)event.getY(index);

Vecteur position0 = new Vecteur(x,y);
Vecteur v0 = this.diagramme.createurCourbeDessineeAndroid.surfaceDessinAndroid.t.applique(position0);

InstantPosition dernierPoint = new InstantPosition(0,v0);
this.setChanged();
this.notifyObservers(dernierPoint);

if (!this.diagramme.createurCourbeDessineeAndroid.surfaceDessinAndroid.rectangleDessin.contains(x,y)) return true;

// à présent on sait que le 1er pointeur est entré dans la zone de dessin
// l'utilisateur commence donc à dessiner une courbe

this.diagramme.createurCourbeDessineeAndroid.courbe.add(dernierPoint);

//renseigner les champs sortieT, sortieX et sortieY

this.suivant.init();
this.diagramme.controleurEtatCourant = this.suivant;

return true;
}
}
