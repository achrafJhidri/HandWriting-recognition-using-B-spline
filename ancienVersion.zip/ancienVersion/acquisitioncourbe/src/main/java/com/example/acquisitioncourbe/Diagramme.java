package com.example.acquisitioncourbe;

import android.view.MotionEvent;
import android.view.View;

import mesmaths.geometrie.base.Vecteur;

public class Diagramme implements View.OnTouchListener
{
CreateurCourbeDessineeAndroid createurCourbeDessineeAndroid;

// ces identifiants sont définis par l'objet MotionEvent
//public Vecteur oldP1, oldP2;   // ??? dans l'ordre : les anciennes positions des deux 1ers doigts posés, iD1 <---> oldP1 et iD2 <---> oldP2

public  ControleurEtat controleurEtat0, controleurEtat1, controleurEtat2, controleurEtat3,
controleurEtatCourant; // mise en oeuvre du DP State : les 4 sommets du graphe et le pointeur sur l'état courant

EcouteurSaisieBords ecouteurSaisieBords;
EcouteurInstantPosition ecouteurInstantPosition;

public void initDiagramme()
{
this.ecouteurSaisieBords = new EcouteurSaisieBords(this.createurCourbeDessineeAndroid);
this.ecouteurInstantPosition = new EcouteurInstantPosition(this.createurCourbeDessineeAndroid);
this.createurCourbeDessineeAndroid.boutonValiderSaisiePointHautDroit.setOnClickListener(this.ecouteurSaisieBords);
this.createurCourbeDessineeAndroid.boutonValiderSaisiePointBasGauche.setOnClickListener(this.ecouteurSaisieBords);
this.controleurEtat0 = new ControleurEtat0(this,null,null);
this.controleurEtat3 = new ControleurEtat3(this,null,this.controleurEtat0);
this.controleurEtat2 = new ControleurEtat2(this,this.controleurEtat0,this.controleurEtat3);
this.controleurEtat1 = new ControleurEtat1(this,this.controleurEtat0,this.controleurEtat2);
this.controleurEtat0.suivant = this.controleurEtat1;

this.controleurEtatCourant = this.controleurEtat0;
this.controleurEtatCourant.init();

this.createurCourbeDessineeAndroid.addObserver(this.ecouteurInstantPosition);
this.createurCourbeDessineeAndroid.addObserver(this.createurCourbeDessineeAndroid.surfaceDessinAndroid);
//this.controleurEtat0.addObserver(this.ecouteurInstantPosition);
//this.controleurEtat0.addObserver(this.createurCourbeDessineeAndroid.surfaceDessinAndroid);
this.controleurEtat1.addObserver(this.ecouteurInstantPosition);
this.controleurEtat2.addObserver(this.ecouteurInstantPosition);
//this.controleurEtat3.addObserver(this.ecouteurInstantPosition); ??
this.controleurEtat2.addObserver(this.createurCourbeDessineeAndroid.surfaceDessinAndroid);
}

public Diagramme(CreateurCourbeDessineeAndroid createurCourbeDessineeAndroid)
{
this.createurCourbeDessineeAndroid = createurCourbeDessineeAndroid;
this.initDiagramme();
}

@Override
public boolean onTouch(View v, MotionEvent event)
{
return this.controleurEtatCourant.onTouch(v,event);
}

}
