package com.example.acquisitioncourbe;

import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import java.util.Observable;

public abstract class ControleurEtat extends Observable
{
public Diagramme diagramme;
public ControleurEtat précédent, suivant;  // état suivant, état précédent. cf. construction du diagramme de transitions d'états dans Diagramme

public ControleurEtat(Diagramme diagramme, ControleurEtat précédent, ControleurEtat suivant)
{
this.diagramme = diagramme;
this.précédent = précédent;
this.suivant = suivant;
}

/**
 * Cette méthode n'est pas évènementielle, elle porte juste ce nom-là par commodité
 */
public abstract boolean onTouch(View v, MotionEvent event);

public void init()
{
String message = "début init de "+this.getClass().getName();
this.diagramme.createurCourbeDessineeAndroid.message.setText(message);
Log.e(ActiviteAcquisition.TAG,message);
}

}