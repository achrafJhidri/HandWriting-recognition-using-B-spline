package com.example.acquisitioncourbe;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.Log;
import android.view.SurfaceView;

import com.dom.malibrairiepersoandroid.DessinateurAndroid;

import java.util.Observable;
import java.util.Observer;
import java.util.Vector;

import mesmaths.geometrie.base.TransformationAffine;
import mesmaths.geometrie.base.Vecteur;
import mesmaths.geometrie.formes.Dessinateur;

public class SurfaceDessinAndroid extends SurfaceView implements Observer
{
CreateurCourbeDessineeAndroid createurCourbeDessineeAndroid;
TransformationAffine t/* monde --> écran */, t_1 /* écran --> monde */;

boolean premierAppelAOnDraw;

Rect rectangleDessin;

public SurfaceDessinAndroid(CreateurCourbeDessineeAndroid createurCourbeDessineeAndroid)
{
super(createurCourbeDessineeAndroid.activiteAcquisition);
int couleur = 0xFF66FF66;
int couleurBidon = 0xFFFF0000;
this.setBackgroundColor(couleur);
//this.setBackgroundColor(this.createurCourbeDessineeAndroid.activiteAcquisition.getColor(R.color.couleurSurface));
//this.createurCourbeDessineeAndroid.activiteAcquisition.getResources(R.color.couleurSurface);
this.createurCourbeDessineeAndroid = createurCourbeDessineeAndroid;
this.premierAppelAOnDraw = true;
this.rectangleDessin = new Rect();
}

@Override
protected void onDraw(Canvas canvas)
{
super.onDraw(canvas);
//Log.e(ActiviteAcquisition.TAG,"appel à onDraw()");

int l = this.getWidth();          // la largeur n'est pas connue avant le 1er appel à onDraw()
int h = this.getHeight();         // la hauteur n'est pas connue avant le 1er appel à onDraw()

//Log.e(ActiviteAcquisition.TAG,"l = " + l + ", h = " + h);

Vecteur P1n, P2n;


P1n = new Vecteur(0,h);
P2n = new Vecteur(l,0);

this.t = new TransformationAffine( this.createurCourbeDessineeAndroid.vMin,
                                   this.createurCourbeDessineeAndroid.vMax,
                                   P1n, P2n);

this.t_1 = t.réciproque();

if (this.premierAppelAOnDraw) { this.premierAppelAOnDraw = false; this.setOnTouchListener(this.createurCourbeDessineeAndroid.diagramme);}

//this.createurCourbeDessineeAndroid.message.setText("transfo affine calculée dans onDraw()");
// dessiner le rectangle et les axes

Vecteur pointBasGauche = t_1.applique(this.createurCourbeDessineeAndroid.vMin);
Vecteur pointHautDroit = t_1.applique(this.createurCourbeDessineeAndroid.vMax);
this.rectangleDessin.set((int)pointBasGauche.x,(int)pointHautDroit.y,(int)pointHautDroit.x,(int)pointBasGauche.y);

Paint paint = new Paint();
paint.setColor(Color.WHITE);

canvas.drawRect(this.rectangleDessin,paint);

Vector<Vecteur> p = this.createurCourbeDessineeAndroid.courbe.getPoints();

if (p.size() <= 1) return;
// à présent, on sait qu'il y a au moins 2 points

//Paint paint = new Paint();
paint.setColor(Color.BLACK);
paint.setStyle(Paint.Style.STROKE);
paint.setStrokeWidth(2);

Dessinateur dessinateur = new DessinateurAndroid(canvas, paint);

Vecteur p1,p2;
int i;
for ( i = 1, p1 = t_1.applique(p.get(0)); i < p.size(); ++i, p1 = p2)
    {
    p2 = t_1.applique(p.get(i));
    dessinateur.dessineSegment(p1,p2);

    }
}

@Override
public void update(Observable o, Object arg)
{
//Log.e(ActiviteAcquisition.TAG,"appel à update de Surface");
this.invalidate(); //provoque l'appel à onDraw()
}
}
