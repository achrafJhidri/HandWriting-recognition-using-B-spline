package com.example.acquisitioncourbe;

import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import mesmaths.geometrie.base.InstantPosition;
import mesmaths.geometrie.base.Vecteur;

/*
* Le 1er pointeur est entré dans la zone de dessin. L'utilisateur a commencé à dessiner une courbe
* */
public class ControleurEtat2 extends ControleurEtat
{
public ControleurEtat2(Diagramme diagramme, ControleurEtat précédent, ControleurEtat suivant)
{
super(diagramme, précédent, suivant);
}

   @Override
public boolean onTouch(View v, MotionEvent event)
{
int action = event.getActionMasked();
int pointerCount = event.getPointerCount();
int actionIndex = event.getActionIndex();
Log.e(ActiviteAcquisition.TAG, "début ControleurEtat2.onTouch(), action = " + action + ", pointerCount = " + pointerCount + ", actionIndex = " + actionIndex);

long dernierInstant = System.currentTimeMillis();
// récupère l'index du 1er doigt qui avait été posé
int index = event.findPointerIndex(((ControleurEtat0)(this.diagramme.controleurEtat0)).iD1);

if ((action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP) && actionIndex == index)
   {
   this.suivant.init();
   this.diagramme.controleurEtatCourant = this.suivant;
   return true;
   } // le 1er pointeur s'est détaché, l'utilisateur a donc fini son dessin

int x = (int)event.getX(index);
int y = (int)event.getY(index);
if (!this.diagramme.createurCourbeDessineeAndroid.surfaceDessinAndroid.rectangleDessin.contains(x,y))
   {
   this.précédent.init();
   this.diagramme.controleurEtatCourant = this.précédent;
   return true;
   }

// à présent on sait que le 1er pointeur est toujours encore dans la zone de dessin
// l'utilisateur continue donc à dessiner une courbe
Vecteur v1 = new Vecteur(x,y);

Vecteur v0 = this.diagramme.createurCourbeDessineeAndroid.surfaceDessinAndroid.t.applique(v1);
int t = (int)(dernierInstant-((ControleurEtat1)(this.diagramme.controleurEtat1)).instantInitial);

InstantPosition dernierPoint = new InstantPosition(t,v0);
this.diagramme.createurCourbeDessineeAndroid.courbe.add(dernierPoint);

this.setChanged();
this.notifyObservers(dernierPoint);

//dessiner la courbe déjà construite
//this.diagramme.createurCourbeDessineeAndroid.surfaceDessinAndroid.invalidate(); déjà fait car la surface est observer

return true;
}
}
