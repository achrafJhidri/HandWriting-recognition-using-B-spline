package com.example.acquisitioncourbe;

import android.view.MotionEvent;
import android.view.View;

import acquisition.modele.CourbeLegendee;
import mesmaths.geometrie.base.InstantPosition;

/*
*
* état n°3, L'utilisateur a fini de dessiner sa courbe, pour revenir à l'état 0, il doit demander à tout effacer
* dans l'état 3, il peut aussi demander à sauver la courbe : cela est pris en charge par l'écouteur de sauvegarde */
public class ControleurEtat3 extends ControleurEtat implements View.OnClickListener
{
EcouteurSauver ecouteurSauver;


@Override
public boolean onTouch(View v, MotionEvent event)
{
return false;
}

/** appelé uniquement quand l'utilisateur veut tout effacer */
@Override
public void onClick(View v)
{

//effacer la courbe
//this.diagramme.createurCourbeDessineeAndroid.set();


//effacer les sorties

//this.setChanged();
//this.notifyObservers();
this.diagramme.createurCourbeDessineeAndroid.boutonEffacer.setOnClickListener(null);
this.diagramme.createurCourbeDessineeAndroid.boutonSauver.setOnClickListener(null);
this.suivant.init();
this.diagramme.controleurEtatCourant = this.suivant;

}

public ControleurEtat3(Diagramme diagramme, ControleurEtat précédent, ControleurEtat suivant)
{
super(diagramme, précédent, suivant);
this.ecouteurSauver = new EcouteurSauver(diagramme.createurCourbeDessineeAndroid);
}

public void init()
{
super.init();
this.diagramme.createurCourbeDessineeAndroid.boutonSauver.setOnClickListener(this.ecouteurSauver);
this.diagramme.createurCourbeDessineeAndroid.boutonEffacer.setOnClickListener(this);

}
}
