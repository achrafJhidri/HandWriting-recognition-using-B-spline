package com.example.acquisitioncourbe;

import android.view.View;

import java.util.Observable;
import java.util.Observer;

import mesmaths.geometrie.base.InstantPosition;

public class EcouteurInstantPosition implements Observer
{
CreateurCourbeDessineeAndroid createurCourbeDessineeAndroid;

public EcouteurInstantPosition(CreateurCourbeDessineeAndroid createurCourbeDessineeAndroid)
{
this.createurCourbeDessineeAndroid = createurCourbeDessineeAndroid;
}

/*
@Override
public void update(Observable o, Object arg)
{
if (!(arg instanceof InstantPosition)) this.createurCourbeDessineeAndroid.message.setText("pb EcouteurInstantPosition");

InstantPosition p = (InstantPosition)arg;
this.createurCourbeDessineeAndroid.sortieT.setText(Double.toString(p.instant));
this.createurCourbeDessineeAndroid.sortieX.setText(Double.toString(p.position.x));
this.createurCourbeDessineeAndroid.sortieY.setText(Double.toString(p.position.y));
}
*/

@Override
public void update(Observable o, Object arg)
{
if (arg == null) { this.setSorties("","",""); return; }

if (!(arg instanceof InstantPosition)) this.createurCourbeDessineeAndroid.message.setText("pb EcouteurInstantPosition");

this.createurCourbeDessineeAndroid.message.setText("");
InstantPosition p = (InstantPosition)arg;
double t = tronque(p.instant,2);
double x = tronque(p.position.x,2);
double y = tronque(p.position.y,2);
this.setSorties(Double.toString(t), Double.toString(x), Double.toString(y));
}

public void setSorties(String t, String x, String y)
{
this.createurCourbeDessineeAndroid.sortieT.setText(t);
this.createurCourbeDessineeAndroid.sortieX.setText(x);
this.createurCourbeDessineeAndroid.sortieY.setText(y);
}

/**
 * @return  la valeur arrondie de x telle que la partie décimale compte nombreChiffresPartieDecimale chiffres
 * */
public static double tronque(double x, int nombreChiffresPartieDecimale)
{
long a = Math.round(x*Math.pow(10,nombreChiffresPartieDecimale));
double y = a*Math.pow(10,-nombreChiffresPartieDecimale);
return y;
}

}