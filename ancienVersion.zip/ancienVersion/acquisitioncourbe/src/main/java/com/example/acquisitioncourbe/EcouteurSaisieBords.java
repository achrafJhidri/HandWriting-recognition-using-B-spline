package com.example.acquisitioncourbe;


import android.view.View;

import mesmaths.geometrie.base.Vecteur;

public class EcouteurSaisieBords implements View.OnClickListener
{
CreateurCourbeDessineeAndroid createurCourbeDessineeAndroid;

public EcouteurSaisieBords(CreateurCourbeDessineeAndroid createurCourbeDessineeAndroid)
{
this.createurCourbeDessineeAndroid = createurCourbeDessineeAndroid;
}

@Override
public void onClick(View v)
{
//gérer aussi l'exception
this.createurCourbeDessineeAndroid.setBords();
}
}
