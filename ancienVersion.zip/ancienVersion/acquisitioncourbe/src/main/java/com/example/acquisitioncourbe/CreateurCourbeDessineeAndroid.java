package com.example.acquisitioncourbe;

import android.util.Log;
import android.view.SurfaceView;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Observable;

import acquisition.modele.CourbeLegendee;
import mesmaths.geometrie.base.TransformationAffine;
import mesmaths.geometrie.base.Vecteur;

public class CreateurCourbeDessineeAndroid extends Observable
{
ActiviteAcquisition activiteAcquisition;

CourbeLegendee courbe; // courbe à construire puis à sauvegarder
Vecteur vMin, vMax;     // rectangle monde tel que vMin.x < vMax.x et vMin.y < vMax.y
Diagramme diagramme;

EditText saisieLegende;
EditText saisiePointHautDroit;
EditText saisiePointBasGauche;

Button boutonValiderSaisiePointHautDroit;
Button boutonValiderSaisiePointBasGauche;
Button boutonSauver;
Button boutonEffacer;

FrameLayout cadreSurface;
SurfaceDessinAndroid surfaceDessinAndroid;

TextView sortieT, sortieX, sortieY;
TextView message;

public CreateurCourbeDessineeAndroid(ActiviteAcquisition activiteAcquisition)
{

this.activiteAcquisition = activiteAcquisition;
this.saisieLegende = (EditText) this.activiteAcquisition.findViewById(R.id.saisieLegende);
this.saisiePointHautDroit = (EditText) this.activiteAcquisition.findViewById(R.id.saisiePointHautDroit);
this.saisiePointBasGauche = (EditText) this.activiteAcquisition.findViewById(R.id.saisiePointBasGauche);
this.boutonValiderSaisiePointHautDroit = (Button) this.activiteAcquisition.findViewById(R.id.boutonValiderSaisiePointHautDroit);
this.boutonValiderSaisiePointBasGauche = (Button) this.activiteAcquisition.findViewById(R.id.boutonValiderSaisiePointBasGauche);
this.boutonSauver = (Button)this.activiteAcquisition.findViewById(R.id.boutonSauver);
this.boutonEffacer = (Button)this.activiteAcquisition.findViewById(R.id.boutonEffacer);
this.sortieT = (TextView) this.activiteAcquisition.findViewById(R.id.sortieT);
this.sortieX = (TextView) this.activiteAcquisition.findViewById(R.id.sortieX);
this.sortieY = (TextView) this.activiteAcquisition.findViewById(R.id.sortieY);

this.message = (TextView) this.activiteAcquisition.findViewById(R.id.message);

this.cadreSurface = (FrameLayout) this.activiteAcquisition.findViewById(R.id.cadreSurface);
this.surfaceDessinAndroid = new SurfaceDessinAndroid(this);
int largeurSurface = 1200;
int hauteurSurface = 600;
float poids = 1;
LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(/*largeurSurface*/ViewGroup.LayoutParams.MATCH_PARENT,
/*hauteurSurface*/ViewGroup.LayoutParams.MATCH_PARENT); // int largeur, int hauteur, float poids
this.cadreSurface.addView(this.surfaceDessinAndroid, params);

Log.e(ActiviteAcquisition.TAG,"creation, surface.getWidth() =  "+this.surfaceDessinAndroid.getWidth());
Log.e(ActiviteAcquisition.TAG,"creation, surface.getHeight() =  "+this.surfaceDessinAndroid.getHeight());

this.diagramme = new Diagramme(this);
// this.surfaceDessinAndroid.setOnTouchListener(this.diagramme); : déplacé dans onDraw()
/*
* android:layout_width="wrap_content"
            android:layout_height="match_parent"
            android:layout_weight="1" />
* */

this.setBordsInitiaux();
}

public void setLégende()
{
//String nomCourbe = this.activiteAcquisition.getString(R.string.saisieLegende);
String nomCourbe = this.saisieLegende.getText().toString();
this.courbe.setLégende(nomCourbe);
}

public void initCourbe()
{
String nomCourbe = this.saisieLegende.getText().toString();
this.courbe = new CourbeLegendee(nomCourbe);
this.setChanged();
this.notifyObservers();
}

public void setBordsInitiaux()
{
this.vMax = new Vecteur(this.activiteAcquisition.getString(R.string.saisiePointHautDroit));
this.vMin = new Vecteur(this.activiteAcquisition.getString(R.string.saisiePointBasGauche));
}

public void setBords()
{
Vecteur oldvMax, oldvMin;

oldvMax = this.vMax;
oldvMin = this.vMin;
try
  {
  this.vMax = new Vecteur(this.saisiePointHautDroit.getText().toString());
  this.vMin = new Vecteur(this.saisiePointBasGauche.getText().toString());
  this.setChanged();
  this.notifyObservers();
  }
catch (Exception e)
      {
      //this.message.setText(R.string.erreurSaisieBords);

      int durée = Toast.LENGTH_SHORT;

      Toast toast = Toast.makeText(this.activiteAcquisition, R.string.erreurSaisieBords, durée);
      toast.show();
      this.vMax = oldvMax; this.saisiePointHautDroit.setText(this.vMax.toString());
      this.vMin = oldvMin; this.saisiePointBasGauche.setText(this.vMin.toString());
      }
}

public void set()
{
this.initCourbe();
this.setBords();

}
}