package com.example.acquisitioncourbe;

import android.content.Intent;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

import acquisition.modele.CourbeLegendee;

class EcouteurSauvegarde implements View.OnClickListener
{
ActiviteSauvegarde activiteSauvegarde;
public EcouteurSauvegarde(ActiviteSauvegarde activiteSauvegarde)
{
this.activiteSauvegarde = activiteSauvegarde;
}

@Override
public void onClick(View v)
{
try
{
Intent intent = this.activiteSauvegarde.getIntent();

CourbeLegendee courbe = (CourbeLegendee) intent.getSerializableExtra("courbe");
String ok = Environment.getExternalStorageState();

if (!ok.equals(Environment.MEDIA_MOUNTED)) throw new Exception("stockage externe absent");

File file = this.activiteSauvegarde.getExternalFilesDir("courbes");
String chemin = file.getAbsolutePath();
this.activiteSauvegarde.messageSauvegarde.setText(chemin);
Log.e(ActiviteAcquisition.TAG,"chemin sauvegarde = " + chemin);
String nom = this.activiteSauvegarde.saisieNomFichier.getText().toString();
String nomFichier = file.getAbsolutePath() + File.separatorChar + nom;
FileOutputStream f1 = new FileOutputStream(nomFichier);
PrintStream f2 = new PrintStream(f1);
courbe.sauve(f2);
f2.close();
this.activiteSauvegarde.messageSauvegarde.setText(this.activiteSauvegarde.getString(R.string.succesSauvegarde) + " sur " + nomFichier);
//this.activiteSauvegarde.messageSauvegarde.setText(this.activiteSauvegarde.getString(R.string.succesSauvegarde));
}

catch (Exception e)
      {
      String message = this.activiteSauvegarde.getString(R.string.echecSauvegarde) + " "+ e;
      Toast toast = Toast.makeText(this.activiteSauvegarde,message,Toast.LENGTH_SHORT);
      toast.show();
      }
}
}

