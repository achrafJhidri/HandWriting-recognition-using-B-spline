package com.example.acquisitioncourbe;

import android.view.View;

class EcouteurRetourAcquisition implements View.OnClickListener
{
ActiviteSauvegarde activiteSauvegarde;

public EcouteurRetourAcquisition(ActiviteSauvegarde activiteSauvegarde)
{
this.activiteSauvegarde = activiteSauvegarde;
}

@Override
public void onClick(View v)
{


this.activiteSauvegarde.finish();
}
}
