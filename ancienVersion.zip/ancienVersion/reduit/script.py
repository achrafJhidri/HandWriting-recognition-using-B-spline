import csv
import os
import re

def get_first_nbr_from_str(input_str):
    '''
    :param input_str: strings that contains digit and words
    :return: the number extracted from the input_str
    demo:
    'ab324.23.123xyz': 324.23
    '.5abc44': 0.5
    '''
    if not input_str and not isinstance(input_str, str):
        return 0
    out_number = ''
    for ele in input_str:
        if (ele == '.' and '.' not in out_number ) or (ele == '-' and '-' not in out_number ) or ele.isdigit():
            out_number += ele
        elif out_number:
            break
    return float(out_number)

def clean(list_s): 

	list_s = list_s.split(',')
	list_s = list(map(get_first_nbr_from_str, list_s))
	list_s = list(dict.fromkeys(list_s))
	return list_s

def searchU(path):

	f = open(path, "r")
	data = f.readlines()
	ListU = []

	for ligne in data:
		if "U[]" in ligne :			
			ListU = clean(ligne)

	return ListU

def searchP(path):

	f = open(path, "r")
	data = f.readlines()
	ListU = []

	for ligne in data:
		if "P[]" in ligne :			
			ListU = clean(ligne)

	return ListU

def first_iter(lenTotal, lenU, lenX): 

		cptX = 0
		cptY = 0
		head = ""
		for i in range(lenTotal):

			if i != 0:
				head += ","

			if i < lenU:
				head += "U" + str(i)
			elif cptX < lenX:
				head += "X" + str(cptX)
				cptX += 1
			else:
				head += "Y" + str(cptY)
				cptY += 1

		head += ',' + "Classe"

		with open(NAME_FILE,'w') as outfile:
			outfile.write(head + "\n")	

SIZE = 61
NAME_FILE = 'dataset.csv'
first_iteration = True

for path in os.listdir("."):
	print(path)
	if path.endswith(".txt"):

		List = searchU(path)
		
		cpt = 0
		ListX = []
		ListY = []

		for p in searchP(path):
			if cpt%2 == 0:
				ListX.append(p)
			else:
				ListY.append(p)
			cpt += 1
		
		if first_iteration == True:
			first_iter(len(List) + len(ListX) + len(ListY), len(List), len(ListX))
			first_iteration = False

		List += ListX + ListY + [path[0]]
		print(len(List))
		if len(List) - 1 != SIZE:
			print("[!] " + path + " \t\t invalide")
			continue

		with open(NAME_FILE,'a', newline='') as file:
			w = csv.writer(file, delimiter=',')
			w.writerow(List)	

		print("[*] " + path + " \t\t insere avec succe")