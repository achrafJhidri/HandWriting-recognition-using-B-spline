package acquisition_mieux;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class EcouteurAbandonSaisieCourbe extends Ecouteur implements
        MouseListener
{

public EcouteurAbandonSaisieCourbe(VueSaisieCourbeGUI vueSaisieCourbeGUI)
{
super(vueSaisieCourbeGUI);
// TODO Auto-generated constructor stub
}

@Override
public void mouseClicked(MouseEvent e)
{
// TODO Auto-generated method stub

}

@Override
public void mouseEntered(MouseEvent e)
{
// TODO Auto-generated method stub

}

@Override
public void mouseExited(MouseEvent e)
{
this.vueSaisieCourbeGUI.quitteEtat2();
this.vueSaisieCourbeGUI.entreEtat0();
}

@Override
public void mousePressed(MouseEvent e)
{
// TODO Auto-generated method stub

}

@Override
public void mouseReleased(MouseEvent e)
{
// TODO Auto-generated method stub

}

}
