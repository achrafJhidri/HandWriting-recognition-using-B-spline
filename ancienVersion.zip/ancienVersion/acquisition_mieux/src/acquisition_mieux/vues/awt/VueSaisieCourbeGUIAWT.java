package acquisition_mieux.vues.awt;

import java.awt.Cursor;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.Observable;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import acquisition_mieux.*;
import mesmaths.geometrie.base.TransformationAffine;
import mesmaths.geometrie.base.Vecteur;
import acquisition_mieux.ecouteurs.EcouteurSaisieBords;
import acquisition_mieux.ecouteurs.EcouteurSaisieCourbe;
import acquisition_mieux.modele.CourbeLegendee;
import acquisition_mieux.vues.CadreSaisieCourbe;

public class VueSaisieCourbeGUIAWT extends VueSaisieCourbeGUI
{
CadreSaisieCourbeAWT cadre;

CourbeLegendee courbe; // courbe � construire puis � sauvegarder
Vecteur vMin, vMax;     // rectangle monde tel que vMin.x < vMax.x et vMin.y < vMax.y
TransformationAffine t/* monde --> �cran */, t_1 /* �cran --> monde */;

EcouteurSaisieBords �couteurSaisieBords; // �coute la saisie du point Bas Gauche et la saisie du point Haut Droit
EcouteurSauver �couteurSauver; //pas fait
EcouteurQuitter �couteurQuitter;
EcouteurEffacer �couteurEffacer;
EcouteurPositionSouris �couteurPositionSouris; // pour afficher les coordonn�es du pointeur de souris
EcouteurSaisieCourbe �couteurSaisieCourbe; // pour la saisie des (t,x(t),y(t)) successifs
EcouteurDebutSaisieCourbe �couteurD�butSaisieCourbe;
EcouteurFinSaisieCourbe �couteurFinSaisieCourbe;
//EcouteurAbandonSaisieCourbe �couteurAbandonSaisieCourbe; // si la souris sort du canvas en pleine construction
EcouteurCanvas �couteurCanvas;
//EcouteurSortieCanvas �couteurSortieCanvas;


///**
//
// */
//public VueSaisieCourbeGUI(double xMin, double yMin, double xMax, double yMax, CadreSaisieCourbe cadre)
//{
//this.cadre = cadre; // � modifier ult�rieurement : cadre doit �tre instanci� ici � l'aide d'une fabrique
///*this.vMin = new Vecteur( xMin, yMin);
//this.vMax = new Vecteur( xMax, yMax);*/
////this.initVminVmax(xMin, yMin, xMax, yMax);
//
//
//this.�couteurSaisieBords = new EcouteurSaisieBords(this);
//this.�couteurSauver = new EcouteurSauver(this);
//this.�couteurQuitter = new EcouteurQuitter();
//this.�couteurEffacer = new EcouteurEffacer(this);
//this.�couteurPositionSouris = new EcouteurPositionSouris(this);
//this.�couteurSaisieCourbe = new EcouteurSaisieCourbe(this);
//this.�couteurD�butSaisieCourbe = new EcouteurDebutSaisieCourbe(this);
//this.�couteurFinSaisieCourbe = new EcouteurFinSaisieCourbe(this);
////this.�couteurAbandonSaisieCourbe = new EcouteurAbandonSaisieCourbe(this);
//this.�couteurCanvas = new EcouteurCanvas(this);
////this.�couteurSortieCanvas = new EcouteurSortieCanvas(this);
//
//
//this.cadre.addWindowListener(this.�couteurQuitter);
//
//
//this.cadre.setVisible(true);
//this.cadre.setVueSaisieCourbe(this);
////this.addObserver(cadre);
//this.initialiseTranformationsAffines(xMin, yMin, xMax, yMax);
//this.cadre.saisiePointBasGauche.setText(this.vMin.toString());
//this.cadre.saisiePointHautDroit.setText(this.vMax.toString());
//this.entreEtat0();
//}

    /**
     * @param xMin
     * @param yMin
     * @param xMax
     * @param yMax
     * @param cadre
     */
    public VueSaisieCourbeGUIAWT(double xMin, double yMin, double xMax, double yMax, CadreSaisieCourbeAWT cadre) {
        super(xMin, yMin, xMax, yMax, cadre);
    }

    private void initVminVmax(double xMin, double yMin, double xMax, double yMax)
{
double x1, y1, x2, y2;

x1 = Math.min(xMin, xMax);
x2 = Math.max(xMin, xMax);
y1 = Math.min(yMin, yMax);
y2 = Math.max(yMin, yMax);

this.vMin = new Vecteur(x1,y1);
this.vMax = new Vecteur(x2,y2);
}

void entreEtat0() // au d�marrage de l'application
{
this.courbe = null;
this.cadre.canvas.repaint();

this.cadre.saisiePointBasGauche.addActionListener(this.�couteurSaisieBords);this.cadre.saisiePointBasGauche.setEditable(true);
this.cadre.saisiePointHautDroit.addActionListener(this.�couteurSaisieBords);this.cadre.saisiePointHautDroit.setEditable(true);
this.cadre.canvas.addMouseListener(this.�couteurCanvas);
//this.cadre.addWindowListener(this.�couteurQuitter);
}

void quitteEtat0()
{
this.cadre.saisiePointBasGauche.removeActionListener(this.�couteurSaisieBords);this.cadre.saisiePointBasGauche.setEditable(false);
this.cadre.saisiePointHautDroit.removeActionListener(this.�couteurSaisieBords);this.cadre.saisiePointHautDroit.setEditable(false);
this.cadre.canvas.removeMouseListener(this.�couteurCanvas);
//this.cadre.removeWindowListener(this.�couteurQuitter);
}

void entreEtat1()
{
//this.cadre.canvas.setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
//this.cadre.saisiePointBasGauche.addActionListener(this.�couteurSaisieBords);
//this.cadre.saisiePointHautDroit.addActionListener(this.�couteurSaisieBords);
this.cadre.canvas.addMouseMotionListener(this.�couteurPositionSouris);
this.cadre.canvas.addMouseListener(this.�couteurD�butSaisieCourbe);
this.cadre.canvas.addMouseListener(this.�couteurCanvas);
}

void quitteEtat1()
{
//this.cadre.canvas.setCursor(Cursor.getDefaultCursor());
//this.cadre.saisiePointBasGauche.removeActionListener(this.�couteurSaisieBords);
//this.cadre.saisiePointHautDroit.removeActionListener(this.�couteurSaisieBords);
this.cadre.canvas.removeMouseMotionListener(this.�couteurPositionSouris);
this.cadre.canvas.removeMouseListener(this.�couteurD�butSaisieCourbe);
this.cadre.canvas.removeMouseListener(this.�couteurCanvas);
}

void entreEtat2()
{
//this.cadre.canvas.setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
this.cadre.canvas.addMouseMotionListener(this.�couteurPositionSouris);
this.cadre.canvas.addMouseMotionListener(this.�couteurSaisieCourbe);
this.cadre.canvas.addMouseListener(this.�couteurFinSaisieCourbe);
//this.cadre.canvas.addMouseListener(this.�couteurAbandonSaisieCourbe);
}

void quitteEtat2()
{
//this.cadre.canvas.setCursor(Cursor.getDefaultCursor());
this.cadre.canvas.removeMouseMotionListener(this.�couteurPositionSouris);
this.cadre.canvas.removeMouseMotionListener(this.�couteurSaisieCourbe);
this.cadre.canvas.removeMouseListener(this.�couteurFinSaisieCourbe);
//this.cadre.canvas.removeMouseListener(this.�couteurAbandonSaisieCourbe);
}

void entreEtat3()
{
this.cadre.toutEffacer.addActionListener(this.�couteurEffacer);
this.cadre.sauver.addActionListener(this.�couteurSauver);
}
void quitteEtat3()
{
this.cadre.toutEffacer.removeActionListener(this.�couteurEffacer);
this.cadre.sauver.removeActionListener(this.�couteurSauver);
}
/*
void passeEtat0Etat1()
{
this.cadre.canvas.setCursor(Cursor.CROSSHAIR_CURSOR);
this.cadre.canvas.addMouseMotionListener(this.�couteurPositionSouris);
this.cadre.canvas.addMouseListener(this.�couteurD�butSaisieCourbe);
this.cadre.canvas.addMouseListener(this.�couteurSortieCanvas);
this.cadre.canvas.removeMouseListener(this.�couteurEntr�eCanvas);
}

void passeEtat1Etat0()
{
this.cadre.canvas.removeMouseMotionListener(this.�couteurPositionSouris);
this.cadre.canvas.removeMouseListener(this.�couteurD�butSaisieCourbe);
this.cadre.canvas.removeMouseListener(this.�couteurSortieCanvas);
this.cadre.canvas.addMouseListener(this.�couteurEntr�eCanvas);
}

void passeEtat1Etat2()
{
this.cadre.canvas.addMouseMotionListener(this.�couteurSaisieCourbe);
this.cadre.canvas.addMouseListener(this.�couteurFinSaisieCourbe);
this.cadre.canvas.addMouseListener(this.�couteurAbandonSaisieCourbe);
this.cadre.saisiePointBasGauche.removeActionListener(this.�couteurSaisieBords);
this.cadre.saisiePointHautDroit.removeActionListener(this.�couteurSaisieBords);

this.cadre.canvas.removeMouseListener(this.�couteurD�butSaisieCourbe);
this.cadre.canvas.removeMouseListener(this.�couteurSortieCanvas);
}

void passeEtat2Etat3()
{
this.cadre.canvas.setCursor(Cursor.getDefaultCursor());
this.cadre.toutEffacer.addActionListener(this.�couteurEffacer);
this.cadre.sauver.addActionListener(this.�couteurSauver);

this.cadre.canvas.removeMouseMotionListener(this.�couteurSaisieCourbe);
this.cadre.canvas.removeMouseListener(this.�couteurFinSaisieCourbe);
this.cadre.canvas.removeMouseListener(this.�couteurAbandonSaisieCourbe);
}

void passeEtat2Etat0()
{
this.courbe = null; // est ce correct ???
this.cadre.toutEffacer.addActionListener(this.�couteurEffacer);
this.cadre.sauver.addActionListener(this.�couteurSauver);

this.cadre.canvas.removeMouseMotionListener(this.�couteurSaisieCourbe);
this.cadre.canvas.removeMouseListener(this.�couteurFinSaisieCourbe);
this.cadre.canvas.removeMouseListener(this.�couteurAbandonSaisieCourbe);
}
*/


public void initialiseTranformationsAffines()
{

this.t = new TransformationAffine( vMin, vMax,
                                   new Vecteur(0,this.cadre.canvas.getHeight()), 
                                   new Vecteur (this.cadre.canvas.getWidth(),0));
this.t_1 = this.t.r�ciproque();


}

public void initialiseTranformationsAffines1() 
{
try
    {
    Vecteur point1 = new Vecteur(this.cadre.saisiePointBasGauche.getText());
    Vecteur point2 = new Vecteur(this.cadre.saisiePointHautDroit.getText());
    
    this.initialiseTranformationsAffines(point1.x, point1.y, point2.x, point2.y);
    this.cadre.canvas.repaint();
    }
catch (RuntimeException e)
    {
    JOptionPane.showMessageDialog(this.cadre, "les points bas gauche et haut droit saisis sont ignor�s car le format :"+
            " \"( abscisse, ordonn�e)\" n'est pas respect�", "erreur de saisie", JOptionPane.ERROR_MESSAGE);
    }
}

private void initialiseTranformationsAffines(double x1, double y1, double x2, double y2)
{
this.initVminVmax(x1, y1, x2, y2);
this.initialiseTranformationsAffines();
/*this.setChanged();
this.notifyObservers();*/
}


public void sauveCourbe()
{
try
{
JFileChooser fileSaver = new JFileChooser();
int r = fileSaver.showSaveDialog(this.cadre);

if (r == JFileChooser.APPROVE_OPTION)
    {
    File file = fileSaver.getSelectedFile();
    System.err.println("r = "+ r + " "+ file.getAbsolutePath());
    PrintStream ps = new PrintStream(file);
    this.courbe.sauve(ps);
    }
}
catch (FileNotFoundException e1)
    {
    JOptionPane.showMessageDialog(this.cadre, 
                                    "sauvegarde impossible", 
                                    "erreur de sauvegarde", 
                                    JOptionPane.ERROR_MESSAGE);
    }



}
}
