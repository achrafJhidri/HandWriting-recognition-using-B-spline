package acquisition_mieux.vues.awt;

import java.awt.*;
import java.util.Observable;
import java.util.Observer;

import acquisition_mieux.MonCanvas;
import acquisition_mieux.VueSaisieCourbeGUI;
import acquisition_mieux.vues.CadreSaisieCourbe;
import outilsvues.Outils;



public class CadreSaisieCourbeAWT extends Frame implements Observer //, CadreSaisieCourbe
{
public Label pr�sentation;
public Label labelsaisieL�gende; public TextField saisieL�gende;

public Label labelX, labelY; public TextField sortieT, sortieX, sortieY;
public Label labelSaisiePointBasGauche, labelSaisiePointHautDroit;
public TextField saisiePointBasGauche, saisiePointHautDroit;

public Button  toutEffacer, sauver;
public MonCanvas canvas;
public TextField message;

public Panel haut, ligne1, ligne2, ligne3, centre, droit, bas, /*ligne1Droite,ligne2Droite, ligne3Droite, ligne4Droite,*/
ligneDroite[];

public CadreSaisieCourbeAWT(String titre,
        String messagePr�sentation,
        String messageSaisieL�gende,
        String messageSaisiePointBasGauche,String pointBasGauche,String messageSaisiePointHautDroit, String pointHautDroit,
        String libell�BoutonToutEffacer, String libell�BoutonSauver,
        String messageModeEmploi, VueSaisieCourbeGUI vue)
{
super(titre);
Outils.place(this, 0.25, 0.25, 0.5, 0.5);
this.setBackground(Color.LIGHT_GRAY);

this.haut = new Panel(); this.add(this.haut,BorderLayout.NORTH);
this.haut.setLayout(new GridLayout(3, 1));

this.ligne1 = new Panel(); this.haut.add(this.ligne1);
this.ligne2 = new Panel(); this.haut.add(this.ligne2);
this.ligne3 = new Panel(); this.haut.add(this.ligne3);


this.canvas = new MonCanvas(vue);this.add(this.canvas,BorderLayout.CENTER);

this.droit = new Panel(); this.add(this.droit,BorderLayout.EAST);
this.droit.setLayout(new GridLayout(5, 1));
this.ligneDroite = new Panel[5];
int i;
for (i = 0; i < 5; ++i)
    {
    this.ligneDroite[i] =new Panel(); this.droit.add(this.ligneDroite[i]);
    }
/*this.ligne1Droite = new Panel(); this.droit.add(this.ligne1Droite);
this.ligne2Droite = new Panel(); this.droit.add(this.ligne2Droite);
this.ligne3Droite = new Panel(); this.droit.add(this.ligne3Droite);
this.ligne4Droite = new Panel(); this.droit.add(this.ligne4Droite);*/

this.bas = new Panel(); this.add(this.bas,BorderLayout.SOUTH);

//this.centre = new Panel(); this.


this.pr�sentation = new Label(messagePr�sentation);
this.ligne1.add(this.pr�sentation);

this.labelsaisieL�gende = new Label(messageSaisieL�gende); this.ligne2.add(this.labelsaisieL�gende);
this.saisieL�gende = new TextField("", 20); this.ligne2.add(this.saisieL�gende);

this.labelSaisiePointBasGauche = new Label(messageSaisiePointBasGauche);this.ligne3.add(this.labelSaisiePointBasGauche);
this.saisiePointBasGauche = new TextField(pointBasGauche,10);this.ligne3.add(this.saisiePointBasGauche);
this.labelSaisiePointHautDroit = new Label(messageSaisiePointHautDroit);this.ligne3.add(this.labelSaisiePointHautDroit);
this.saisiePointHautDroit = new TextField(pointHautDroit,10);this.ligne3.add(this.saisiePointHautDroit);

this.toutEffacer = new Button(libell�BoutonToutEffacer); this.ligneDroite[0].add(this.toutEffacer);
this.sauver = new Button(libell�BoutonSauver); this.ligneDroite[1].add(this.sauver);
this.ligneDroite[2].add(new Label("t"));
this.sortieT = new TextField("",3);this.sortieT.setEditable(false);this.ligneDroite[2].add(this.sortieT);
this.labelX = new Label("x");this.ligneDroite[3].add(this.labelX);
this.sortieX = new TextField("",3); this.sortieX.setEditable(false);this.ligneDroite[3].add(this.sortieX);

this.labelY = new Label("y");this.ligneDroite[4].add(this.labelY);
this.sortieY = new TextField("",3); this.sortieY.setEditable(false);this.ligneDroite[4].add(this.sortieY);

this.message = new TextField(messageModeEmploi,80);
this.message.setEditable(false);
//this.bas.add(new Label(" "));
this.bas.add(this.message);
}



/*public void CadreSaisieCourbe1(String titre)
{
//super(titre);
Outils.place(this, 0.25, 0.25, 0.5, 0.5);
this.setBackground(Color.LIGHT_GRAY);

this.haut = new Panel(); this.add(this.haut,BorderLayout.NORTH);
this.haut.setLayout(new GridLayout(3, 1));

this.ligne1 = new Panel(); this.haut.add(this.ligne1);
this.ligne2 = new Panel(); this.haut.add(this.ligne2);
this.ligne3 = new Panel(); this.haut.add(this.ligne3);


this.canvas = new MonCanvas(); this.canvas.setBackground(Color.white);this.add(this.canvas,BorderLayout.CENTER);

this.droit = new Panel(); this.add(this.droit,BorderLayout.EAST);
this.droit.setLayout(new GridLayout(2, 1));
this.ligne1Droite = new Panel(); this.droit.add(this.ligne1Droite);
this.ligne2Droite = new Panel(); this.droit.add(this.ligne2Droite);

this.bas = new Panel(); this.add(this.bas,BorderLayout.SOUTH);

//this.centre = new Panel(); this.


this.pr�sentation = new Label("saisie de courbe trac�e � la main."+
        " Les triplets ( t, x(t), y(t) )  instant-position successifs sont saisis ");
this.ligne1.add(this.pr�sentation);

this.labelsaisieL�gende = new Label("saisie de la l�gende de la courbe"); this.ligne2.add(this.labelsaisieL�gende);
this.saisieL�gende = new TextField("", 20); this.ligne2.add(this.saisieL�gende);

this.labelSaisiePointBasGauche = new Label("saisie point bas gauche");this.ligne3.add(this.labelSaisiePointBasGauche);
this.saisiePointBasGauche = new TextField("(0,0)",10);this.ligne3.add(this.saisiePointBasGauche);
this.labelSaisiePointHautDroit = new Label("saisie point haut droit");this.ligne3.add(this.labelSaisiePointHautDroit);
this.saisiePointHautDroit = new TextField("(1,1)",10);this.ligne3.add(this.saisiePointHautDroit);

this.toutEffacer = new Button("tout effacer"); this.ligne1Droite.add(this.toutEffacer);
this.sauver = new Button("sauver"); this.ligne2Droite.add(this.sauver);

this.message = new TextField("d�but de courbe <--> enfoncer bouton gauche souris. fin de courbe <--> rel�cher bouton gauche souris",80);
this.message.setEditable(false);
//this.bas.add(new Label(" "));
this.bas.add(this.message);


}*/


/* (non-Javadoc)
 * @see acquisition_mieux.vues.awt.CadreSaisieCourbe#setVueSaisieCourbe(acquisition_mieux.VueSaisieCourbeGUI)
 */

public void setVueSaisieCourbe(VueSaisieCourbeGUI vueSaisieCourbe)
{
this.canvas.vue = vueSaisieCourbe;
}



@Override
public void update(Observable arg0, Object arg1)
{
VueSaisieCourbeGUI vue = (VueSaisieCourbeGUI)arg0;
this.saisiePointBasGauche.setText(vue.vMin.toString());
this.saisiePointHautDroit.setText(vue.vMax.toString());
this.canvas.repaint();

}

}
