package acquisition_mieux.vues;

import java.awt.Button;
import java.awt.Label;
import java.awt.TextField;
import java.util.Observable;

import acquisition_mieux.MonCanvas;
import acquisition_mieux.VueSaisieCourbeGUI;

public interface CadreSaisieCourbe
{
Label pr�sentation = new Label();
Label labelsaisieL�gende = new Label(); TextField saisieL�gende = new TextField();

Label labelX = new Label(), labelY = new Label(); TextField sortieT = new TextField(), sortieX = new TextField(), sortieY = new TextField();
Label labelSaisiePointBasGauche = new Label(), labelSaisiePointHautDroit = new Label();
TextField saisiePointBasGauche = new TextField(), saisiePointHautDroit = new TextField();

MonCanvas canvas = null;
TextField message = new TextField();

void setVueSaisieCourbe(VueSaisieCourbeGUI vueSaisieCourbe);

public String getLegende(); // saisie L�gende
public String getPointBasGauche(); // saisie point bas gauche
public String getPointHautDroit(); // saisie point haut droit
public void setSortieT();
public void setSortieX();
public void setSortieY();
public void setMessage();
public Observable getBoutonToutEffacer();//Button  toutEffacer;

public Observable getBoutonSauver();//Button  sauver;


}