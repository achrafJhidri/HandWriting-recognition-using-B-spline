package acquisition_mieux;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import acquisition_mieux.ecouteurs.Ecouteur;
import acquisition_mieux.modele.CourbeLegendee;

public class EcouteurDebutSaisieCourbe extends Ecouteur implements
        MouseListener
{
public long debut; // instant initial du trac� d'une courbe
public EcouteurDebutSaisieCourbe(VueSaisieCourbeGUI vueSaisieCourbeGUI)
{
super(vueSaisieCourbeGUI);

}

@Override
public void mouseClicked(MouseEvent e)
{
// TODO Auto-generated method stub

}

@Override
public void mouseEntered(MouseEvent e)
{
// TODO Auto-generated method stub

}

@Override
public void mouseExited(MouseEvent e)
{
}

@Override
public void mousePressed(MouseEvent e)
{
if (e.getButton() == MouseEvent.BUTTON1)
    {
    this.debut = System.currentTimeMillis(); // on note l'instant de d�part de la courbe

    // on cr�e la courbe vide pour l'instant
    this.vueSaisieCourbeGUI.courbe = new CourbeLegendee(this.vueSaisieCourbeGUI.cadre.saisieL�gende.getText());
    this.vueSaisieCourbeGUI.quitteEtat1();
    this.vueSaisieCourbeGUI.entreEtat2();
    }
}

@Override
public void mouseReleased(MouseEvent e)
{
}
}
