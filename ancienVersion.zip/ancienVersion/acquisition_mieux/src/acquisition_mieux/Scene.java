package acquisition_mieux;

import java.awt.Graphics;

public interface Scene
{

    void dessiner(Graphics arg0);

}
