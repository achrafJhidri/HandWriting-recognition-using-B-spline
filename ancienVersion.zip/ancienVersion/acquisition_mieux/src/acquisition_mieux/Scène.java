package acquisition_mieux;

import java.awt.*;

public interface Scène
{

    void dessiner(Graphics arg0);

}
